// import React from "react";
// import "./Testimonial.css";

// const Testimonial = () => {
//   return (
//     <div id="testimonial">
//       <div className="demo">
//         <div className="container">
//           <div className="row">
//             <div className="col-md-8">
//               <div id="testimonial-slider" className="owl-carousel">
//                 <div className="testimonial">
//                   <div className="pic">
//                     <img src="https://www.therapidhire.com/assets/img/team/Shraddhha.jpg" />
//                   </div>
//                   <h3 className="title">Williamson</h3>
//                   <span className="post">Web Developer</span>
//                   <p className="description">
//                     Lorem ipsum dolor sit amet, consectetur adipisicing elit. A
//                     accusantium ad asperiores at atque culpa dolores eaque
//                     fugiat hic illo ipsam ipsum minima modi necessitatibus nemo
//                     officia, omnis perferendis placeat sit vitae, consectetur
//                     adipisicing elit ipsam.
//                   </p>
//                 </div>
//                 <div className="testimonial">
//                   <div className="pic">
//                     <img src="https://www.therapidhire.com/assets/img/team/Shraddhha.jpg" />
//                   </div>
//                   <h3 className="title">Kristina</h3>
//                   <span className="post">Web Designer</span>
//                   <p className="description">
//                     Lorem ipsum dolor sit amet, consectetur adipisicing elit. A
//                     accusantium ad asperiores at atque culpa dolores eaque
//                     fugiat hic illo ipsam ipsum minima modi necessitatibus nemo
//                     officia, omnis perferendis placeat sit vitae, consectetur
//                     adipisicing elit ipsam.
//                   </p>
//                 </div>
//               </div>
//             </div>
//           </div>
//         </div>
//       </div>
//     </div>
//   );
// };

// export default Testimonial;
